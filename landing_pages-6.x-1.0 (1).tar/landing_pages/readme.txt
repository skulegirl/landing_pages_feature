A quick feature that is based on the content at http://www.gizra.com/content/dynamic-landing-pages/
